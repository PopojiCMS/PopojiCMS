<?=$this->layout('index');?>

<section id="content">
	<div class="content-wrap">
		<div class="container clearfix">
			<div class="col_full text-center">
				<div class="error404">404</div>
				<div class="heading-block nobottomborder">
					<h4><?=$this->e($front_404_text);?></h4>
				</div>
			</div>
		</div>
	</div>
</section>