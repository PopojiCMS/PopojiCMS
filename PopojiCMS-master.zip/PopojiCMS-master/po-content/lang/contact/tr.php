<?php
/**
 *
 * - PopojiCMS Contact Language
 *
 * - File : tr.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - Developed by: Yohanes Guntur
 * - License : MIT License
 *
*/

$_['component_name'] = 'iletişim';
$_['contact_name'] = 'ad';
$_['contact_email'] = 'e-posta';
$_['contact_subject'] = 'Subject';
$_['contact_message'] = 'ileti';
$_['contact_action'] = 'eylem';
$_['contact_read'] = 'okundu olarak işaretle';
$_['contact_notread'] = 'okundu olarak işaretle';
$_['contact_view'] = 'Görünüm';
$_['contact_reply'] = 'cevap';
$_['contact_dialog_title_1'] = 'detay';
$_['contact_dialog_title_2'] = 'cevap';
$_['contact_message_1'] = 'kişi yanıtı başarıyla gönderildi';
$_['contact_message_2'] = 'kişi başarıyla silindi';
$_['contact_message_3'] = 'hata gönderilmiş kişi yanıtı';
$_['contact_message_4'] = 'hata silindi kişi verileri';