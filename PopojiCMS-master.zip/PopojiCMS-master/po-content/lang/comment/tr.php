<?php
/**
 *
 * - PopojiCMS Comment Language
 *
 * - File : tr.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - Developed by: Yohanes Guntur
 * - License : MIT License
 *
*/

$_['component_name'] = 'Yorum';
$_['comment_name'] = 'yorum';
$_['comment_date'] = 'DateTime';
$_['comment_publish'] = 'Yayımla';
$_['comment_action'] = 'eylem';
$_['comment_read'] = 'okundu olarak işaretle';
$_['comment_notread'] = 'okundu olarak işaretle';
$_['comment_act_publish'] = 'yorum Yayınla';
$_['comment_act_notpublish'] = 'yorumlamayı Kaldır';
$_['comment_view'] = 'Görünüm';
$_['comment_reply'] = 'cevap';
$_['comment_dialog_title_1'] = 'detay';
$_['comment_dialog_title_2'] = 'cevap';
$_['comment_message_1'] = 'yorum yanıtı başarıyla yayınlanmıştır';
$_['comment_message_2'] = 'yorum başarıyla silindi';
$_['comment_message_3'] = 'hata Posted Comment Yanıtla';
$_['comment_message_4'] = 'hata yorum verisi silindi';