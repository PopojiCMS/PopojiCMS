<?php
/**
 *
 * - PopojiCMS Library Language
 *
 * - File : tr.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - Developed by: Yohanes Guntur
 * - License : MIT License
 *
*/

$_['component_name'] = 'Kütüphane';
$_['library_name'] = 'ad';
$_['library_type'] = 'Type';
$_['library_size'] = 'boyut';
$_['library_date'] = 'modifiye';
$_['library_action'] = 'eylem';
$_['library_addnew'] = 'Kütüphane Ekle';
$_['library_message_1'] = 'Library başarıyla eklendi';
$_['library_message_2'] = 'Kütüphane başarıyla silindi';
$_['library_message_3'] = 'yeni arşiv verisi eklendi';
$_['library_message_4'] = 'hata silindi kitaplığı verileri';